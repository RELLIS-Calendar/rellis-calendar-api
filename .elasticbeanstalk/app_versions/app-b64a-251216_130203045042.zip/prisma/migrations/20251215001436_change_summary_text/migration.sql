-- AlterTable
ALTER TABLE `event` MODIFY `summary` TEXT NULL;
