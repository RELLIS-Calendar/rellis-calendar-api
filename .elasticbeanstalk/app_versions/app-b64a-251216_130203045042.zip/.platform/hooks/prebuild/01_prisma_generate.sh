#!/bin/bash
# .platform/hooks/prebuild/01_prisma_generate.sh
# This runs AFTER npm install but BEFORE the app starts

set -e

echo "=========================================="
echo "Running Prisma generate..."
echo "=========================================="

cd /var/app/staging

# Check if prisma is installed
if [ -f "node_modules/.bin/prisma" ]; then
    echo "Prisma CLI found, generating client..."
    ./node_modules/.bin/prisma generate
    echo "Prisma client generated successfully!"
else
    echo "WARNING: Prisma CLI not found in node_modules"
    exit 1
fi

echo "=========================================="

