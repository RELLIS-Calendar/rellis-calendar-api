#!/bin/bash

echo "🔍 CHECKING DATABASE CONNECTION..."
echo ""

# Test if the database port is actually 30365 or 3306
echo "1️⃣  Testing connection to DB on port 30365 (current setting):"
timeout 5 bash -c "cat < /dev/null > /dev/tcp/rellis-calendar.c30cqa0m88cx.us-east-2.rds.amazonaws.com/30365" 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Port 30365 is OPEN"
else
    echo "❌ Port 30365 is CLOSED or unreachable"
fi
echo ""

echo "2️⃣  Testing connection to DB on port 3306 (standard MariaDB port):"
timeout 5 bash -c "cat < /dev/null > /dev/tcp/rellis-calendar.c30cqa0m88cx.us-east-2.rds.amazonaws.com/3306" 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Port 3306 is OPEN - THIS IS THE CORRECT PORT!"
else
    echo "❌ Port 3306 is CLOSED or unreachable"
fi
echo ""

echo "═══════════════════════════════════════════════════════════"
echo "CONCLUSION:"
echo "The database is likely on port 3306, not 30365."
echo "Change DB_PORT to 3306 in EB environment variables."
echo "═══════════════════════════════════════════════════════════"

