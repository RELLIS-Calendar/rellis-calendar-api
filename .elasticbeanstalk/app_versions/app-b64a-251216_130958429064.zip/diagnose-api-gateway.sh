#!/bin/bash

# API Gateway Diagnostic and Fix Script

API_ID="p4o6wzh11c"
REGION="us-east-2"
EB_URL="http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com"

echo "🔍 Diagnosing API Gateway: $API_ID"
echo ""

# Test backend directly
echo "1️⃣  Testing backend directly..."
BACKEND_TEST=$(curl -s -o /dev/null -w "%{http_code}" "$EB_URL/api/events")
if [ "$BACKEND_TEST" = "200" ]; then
    echo "   ✅ Backend is responding (HTTP $BACKEND_TEST)"
else
    echo "   ⚠️  Backend returned HTTP $BACKEND_TEST"
    echo "   Testing backend health..."
    curl -s "$EB_URL/api/health" || echo "Backend not responding"
fi
echo ""

# Get API details
echo "2️⃣  Checking API Gateway configuration..."
aws apigatewayv2 get-api --api-id "$API_ID" --region "$REGION" --output json > /tmp/api-details.json 2>&1

if [ $? -eq 0 ]; then
    echo "   ✅ API Gateway found"
    cat /tmp/api-details.json | grep -E '"Name"|"ApiEndpoint"'
else
    echo "   ❌ Could not retrieve API details"
    cat /tmp/api-details.json
    exit 1
fi
echo ""

# Check integrations
echo "3️⃣  Checking integrations..."
aws apigatewayv2 get-integrations --api-id "$API_ID" --region "$REGION" --output json > /tmp/integrations.json 2>&1

if [ $? -eq 0 ]; then
    INTEGRATION_COUNT=$(cat /tmp/integrations.json | grep -o '"IntegrationId"' | wc -l)
    echo "   Found $INTEGRATION_COUNT integration(s)"
    cat /tmp/integrations.json | grep -E '"IntegrationUri"|"IntegrationMethod"'
else
    echo "   ⚠️  Could not retrieve integrations"
fi
echo ""

# Check routes
echo "4️⃣  Checking routes..."
aws apigatewayv2 get-routes --api-id "$API_ID" --region "$REGION" --output json > /tmp/routes.json 2>&1

if [ $? -eq 0 ]; then
    ROUTE_COUNT=$(cat /tmp/routes.json | grep -o '"RouteKey"' | wc -l)
    echo "   Found $ROUTE_COUNT route(s):"
    cat /tmp/routes.json | grep '"RouteKey"'

    # Check if we have the catch-all route
    if grep -q '"RouteKey": "ANY /{proxy+}"' /tmp/routes.json; then
        echo "   ✅ Catch-all route exists"
    else
        echo "   ⚠️  No catch-all route found!"
        echo ""
        echo "   🔧 FIX: You need to add a route:"
        echo "      Route Key: ANY /{proxy+}"
        echo "      Or use: $ANY /\$default"
    fi
else
    echo "   ⚠️  Could not retrieve routes"
fi
echo ""

# Test API Gateway
echo "5️⃣  Testing API Gateway endpoint..."
API_TEST=$(curl -s -o /dev/null -w "%{http_code}" "https://$API_ID.execute-api.$REGION.amazonaws.com/api/events")
echo "   Response: HTTP $API_TEST"

if [ "$API_TEST" = "200" ]; then
    echo "   ✅ API Gateway is working!"
    echo ""
    echo "   Sample response:"
    curl -s "https://$API_ID.execute-api.$REGION.amazonaws.com/api/events" | head -20
elif [ "$API_TEST" = "404" ]; then
    echo "   ❌ 404 Not Found - Route configuration issue"
    echo ""
    echo "   🔧 FIXES TO TRY:"
    echo ""
    echo "   Option 1: Update integration URI to include {proxy}"
    INTEGRATION_ID=$(cat /tmp/integrations.json | grep -o '"IntegrationId": "[^"]*' | head -1 | sed 's/"IntegrationId": "//')
    if [ ! -z "$INTEGRATION_ID" ]; then
        echo "   aws apigatewayv2 update-integration \\"
        echo "     --api-id $API_ID \\"
        echo "     --integration-id $INTEGRATION_ID \\"
        echo "     --integration-uri '$EB_URL/\${request.path}' \\"
        echo "     --region $REGION"
    fi
    echo ""
    echo "   Option 2: Or use this simpler integration URI:"
    echo "   Integration URI: $EB_URL"
    echo "   Request Parameters: Append path to URL: ✅ Enabled"
else
    echo "   ⚠️  Unexpected response: HTTP $API_TEST"
fi
echo ""

# Check stages
echo "6️⃣  Checking deployment stages..."
aws apigatewayv2 get-stages --api-id "$API_ID" --region "$REGION" --output json > /tmp/stages.json 2>&1

if [ $? -eq 0 ]; then
    STAGE_COUNT=$(cat /tmp/stages.json | grep -o '"StageName"' | wc -l)
    echo "   Found $STAGE_COUNT stage(s):"
    cat /tmp/stages.json | grep -E '"StageName"|"AutoDeploy"'
else
    echo "   ⚠️  Could not retrieve stages"
fi
echo ""

echo "═══════════════════════════════════════════════════════════"
echo "📋 SUMMARY"
echo "═══════════════════════════════════════════════════════════"
echo "Backend URL: $EB_URL"
echo "API Gateway: https://$API_ID.execute-api.$REGION.amazonaws.com"
echo ""
echo "If you see 404 errors, the most common fix is:"
echo "1. Go to AWS Console → API Gateway → $API_ID"
echo "2. Click 'Routes' in left menu"
echo "3. Verify route exists: ANY /{proxy+}"
echo "4. Click 'Integrations'"
echo "5. Verify Integration URI: $EB_URL"
echo "6. Or better: $EB_URL/\${request.path}"
echo ""
echo "Then redeploy the stage."
echo "═══════════════════════════════════════════════════════════"

