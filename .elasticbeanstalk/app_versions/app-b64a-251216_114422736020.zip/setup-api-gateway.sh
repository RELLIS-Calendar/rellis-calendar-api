#!/bin/bash

# Automated API Gateway Setup Script
# This creates an HTTP API Gateway that proxies to your Elastic Beanstalk environment

set -e

# Configuration
API_NAME="rellis-calendar-api-gateway"
EB_URL="http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com"
REGION="us-east-2"
STAGE_NAME="prod"
AMPLIFY_ORIGIN="https://main.d2nd1e6tb57dgk.amplifyapp.com"

echo "🚀 Creating API Gateway for Rellis Calendar API..."
echo ""

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI not found. Please install it first:"
    echo "   brew install awscli"
    exit 1
fi

echo "📡 Creating HTTP API..."
API_OUTPUT=$(aws apigatewayv2 create-api \
  --name "$API_NAME" \
  --protocol-type HTTP \
  --region "$REGION" \
  --cors-configuration "AllowOrigins=$AMPLIFY_ORIGIN,AllowMethods=GET,POST,PUT,DELETE,OPTIONS,AllowHeaders=Content-Type,Authorization" \
  --output json)

API_ID=$(echo "$API_OUTPUT" | grep -o '"ApiId": "[^"]*' | sed 's/"ApiId": "//')
API_ENDPOINT=$(echo "$API_OUTPUT" | grep -o '"ApiEndpoint": "[^"]*' | sed 's/"ApiEndpoint": "//')

echo "✅ API Created!"
echo "   API ID: $API_ID"
echo "   Endpoint: $API_ENDPOINT"
echo ""

echo "🔗 Creating integration to Elastic Beanstalk..."
INTEGRATION_OUTPUT=$(aws apigatewayv2 create-integration \
  --api-id "$API_ID" \
  --integration-type HTTP_PROXY \
  --integration-method ANY \
  --integration-uri "$EB_URL/{proxy}" \
  --payload-format-version 1.0 \
  --region "$REGION" \
  --output json)

INTEGRATION_ID=$(echo "$INTEGRATION_OUTPUT" | grep -o '"IntegrationId": "[^"]*' | sed 's/"IntegrationId": "//')

echo "✅ Integration Created!"
echo "   Integration ID: $INTEGRATION_ID"
echo ""

echo "🛣️  Creating route..."
aws apigatewayv2 create-route \
  --api-id "$API_ID" \
  --route-key 'ANY /{proxy+}' \
  --target "integrations/$INTEGRATION_ID" \
  --region "$REGION" \
  --output json > /dev/null

echo "✅ Route Created!"
echo ""

echo "🚢 Creating stage and deploying..."
aws apigatewayv2 create-stage \
  --api-id "$API_ID" \
  --stage-name "$STAGE_NAME" \
  --auto-deploy \
  --region "$REGION" \
  --output json > /dev/null

echo "✅ Stage Created and Deployed!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎉 API Gateway Setup Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📝 Your API Gateway URL:"
echo "   $API_ENDPOINT"
echo ""
echo "🧪 Test your API:"
echo "   curl $API_ENDPOINT/api/events"
echo ""
echo "📋 Next Steps:"
echo "   1. Update your Amplify redirects.json with:"
echo "      \"target\": \"$API_ENDPOINT/<*>\""
echo ""
echo "   2. Or update amplify.yml redirects section with:"
echo "      target: '$API_ENDPOINT/<*>'"
echo ""
echo "   3. Commit and push to deploy frontend changes"
echo ""
echo "💰 Cost: ~$1 per million requests (much cheaper than ALB!)"
echo ""

