#!/bin/bash

# Quick redeploy script for AWS Elastic Beanstalk
# This script assumes you're deploying from the deploy directory

set -e

echo "🚀 Redeploying to AWS Elastic Beanstalk..."
echo ""

# Navigate to deploy directory
cd "$(dirname "$0")/deploy"

echo "📁 Current directory: $(pwd)"
echo ""

# Check if EB is initialized
if [ ! -d ".elasticbeanstalk" ]; then
    echo "❌ Error: Elastic Beanstalk not initialized in deploy directory"
    echo ""
    echo "Please run these commands first:"
    echo "  cd deploy"
    echo "  eb init"
    echo ""
    exit 1
fi

# Deploy
echo "🚢 Deploying to Elastic Beanstalk..."
eb deploy

echo ""
echo "✅ Deployment complete!"
echo ""
echo "Check status with: cd deploy && eb status"
echo "View logs with: cd deploy && eb logs"

