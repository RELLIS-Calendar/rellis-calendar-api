#!/bin/bash
# .platform/hooks/postdeploy/01_prisma_generate.sh
# This runs AFTER npm install completes

set -e

echo "=========================================="
echo "Running Prisma generate after deployment..."
echo "=========================================="

cd /var/app/current

# Generate Prisma client
if [ -f "node_modules/.bin/prisma" ]; then
    echo "Generating Prisma client..."
    ./node_modules/.bin/prisma generate
    echo "Prisma client generated successfully!"
else
    echo "ERROR: Prisma CLI not found"
    exit 1
fi

echo "=========================================="

