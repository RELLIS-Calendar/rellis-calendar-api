#!/bin/bash

echo "═══════════════════════════════════════════════════════════"
echo "   🔍 COMPLETE DIAGNOSTIC REPORT"
echo "═══════════════════════════════════════════════════════════"
echo ""

# 1. Test Backend Directly
echo "1️⃣  Testing Elastic Beanstalk Backend..."
echo "URL: http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events"
echo ""
BACKEND_RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events 2>&1)
BACKEND_CODE=$(echo "$BACKEND_RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
BACKEND_BODY=$(echo "$BACKEND_RESPONSE" | grep -v "HTTP_CODE")

if [ "$BACKEND_CODE" = "200" ]; then
    echo "✅ Backend is WORKING - HTTP 200"
    echo "Sample response:"
    echo "$BACKEND_BODY" | head -10
elif [ -z "$BACKEND_CODE" ]; then
    echo "❌ Backend is NOT RESPONDING (connection failed)"
    echo "Error: $BACKEND_RESPONSE"
else
    echo "⚠️  Backend returned HTTP $BACKEND_CODE"
    echo "Response: $BACKEND_BODY"
fi
echo ""
echo "───────────────────────────────────────────────────────────"
echo ""

# 2. Test API Gateway
echo "2️⃣  Testing API Gateway..."
echo "URL: https://p4o6wzh11c.execute-api.us-east-2.amazonaws.com/api/events"
echo ""
APIGW_RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" https://p4o6wzh11c.execute-api.us-east-2.amazonaws.com/api/events 2>&1)
APIGW_CODE=$(echo "$APIGW_RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
APIGW_BODY=$(echo "$APIGW_RESPONSE" | grep -v "HTTP_CODE")

if [ "$APIGW_CODE" = "200" ]; then
    echo "✅ API Gateway is WORKING - HTTP 200"
    echo "Sample response:"
    echo "$APIGW_BODY" | head -10
elif [ "$APIGW_CODE" = "404" ]; then
    echo "❌ API Gateway returns 404 Not Found"
    echo "Response: $APIGW_BODY"
    echo ""
    echo "Diagnosis: Route/Integration configuration issue"
elif [ -z "$APIGW_CODE" ]; then
    echo "❌ API Gateway is NOT RESPONDING"
    echo "Error: $APIGW_RESPONSE"
else
    echo "⚠️  API Gateway returned HTTP $APIGW_CODE"
    echo "Response: $APIGW_BODY"
fi
echo ""
echo "───────────────────────────────────────────────────────────"
echo ""

# 3. Test Amplify redirect (if frontend is deployed)
echo "3️⃣  Testing Amplify Frontend Redirect..."
echo "URL: https://main.d2nd1e6tb57dgk.amplifyapp.com/api/events"
echo ""
AMPLIFY_RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" https://main.d2nd1e6tb57dgk.amplifyapp.com/api/events 2>&1)
AMPLIFY_CODE=$(echo "$AMPLIFY_RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
AMPLIFY_BODY=$(echo "$AMPLIFY_RESPONSE" | grep -v "HTTP_CODE")

if [ "$AMPLIFY_CODE" = "200" ]; then
    echo "✅ Amplify redirect is WORKING - HTTP 200"
    echo "Sample response:"
    echo "$AMPLIFY_BODY" | head -10
elif [ "$AMPLIFY_CODE" = "404" ]; then
    echo "⚠️  Amplify returns 404"
    echo "Response: $AMPLIFY_BODY"
    echo ""
    echo "Note: This is expected if you haven't deployed frontend changes yet"
elif [ -z "$AMPLIFY_CODE" ]; then
    echo "❌ Amplify is NOT RESPONDING"
    echo "Error: $AMPLIFY_RESPONSE"
else
    echo "⚠️  Amplify returned HTTP $AMPLIFY_CODE"
    echo "Response: $AMPLIFY_BODY"
fi
echo ""
echo "───────────────────────────────────────────────────────────"
echo ""

# 4. Check EB Status
echo "4️⃣  Checking Elastic Beanstalk Status..."
cd "/Users/jacksonbailey/Library/CloudStorage/GoogleDrive-jbailey33@leomail.tamuc.edu/My Drive/Web Programming & Interface Design/rellis-calendar-api"
EB_STATUS=$(eb status 2>&1)
EB_HEALTH=$(echo "$EB_STATUS" | grep "Health:" | awk '{print $2}')

if [ "$EB_HEALTH" = "Green" ] || [ "$EB_HEALTH" = "Ok" ]; then
    echo "✅ EB Environment Health: $EB_HEALTH"
elif [ "$EB_HEALTH" = "Red" ] || [ "$EB_HEALTH" = "Severe" ]; then
    echo "❌ EB Environment Health: $EB_HEALTH (UNHEALTHY)"
elif [ -z "$EB_HEALTH" ]; then
    echo "⚠️  Could not determine EB health"
else
    echo "⚠️  EB Environment Health: $EB_HEALTH"
fi

echo "$EB_STATUS" | grep -E "Status:|CNAME:|Updated:" | head -5
echo ""
echo "───────────────────────────────────────────────────────────"
echo ""

# 5. Summary
echo "═══════════════════════════════════════════════════════════"
echo "   📋 SUMMARY"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "Backend (EB):     HTTP $BACKEND_CODE"
echo "API Gateway:      HTTP $APIGW_CODE"
echo "Amplify:          HTTP $AMPLIFY_CODE"
echo "EB Health:        $EB_HEALTH"
echo ""

# Diagnosis
echo "🔍 DIAGNOSIS:"
echo ""

if [ "$BACKEND_CODE" != "200" ]; then
    echo "❌ PRIMARY ISSUE: Backend is not responding correctly"
    echo ""
    echo "ACTIONS NEEDED:"
    echo "1. Check EB environment: eb status"
    echo "2. Check EB logs: eb logs"
    echo "3. Verify deployment succeeded"
    echo "4. Check if app is running: eb ssh then 'ps aux | grep node'"
    echo ""
elif [ "$APIGW_CODE" = "404" ]; then
    echo "❌ PRIMARY ISSUE: API Gateway routing problem"
    echo ""
    echo "ACTIONS NEEDED:"
    echo "1. Go to API Gateway console"
    echo "2. Check Routes → ANY /{proxy+} is attached to integration"
    echo "3. Check Integration URI has {proxy}"
    echo "4. Deploy the stage"
    echo ""
elif [ "$APIGW_CODE" = "200" ] && [ "$AMPLIFY_CODE" != "200" ]; then
    echo "⚠️  API Gateway works, but Amplify redirect doesn't"
    echo ""
    echo "ACTIONS NEEDED:"
    echo "1. Deploy frontend with updated redirects.json"
    echo "2. cd rellis-calendar-web"
    echo "3. git add public/redirects.json"
    echo "4. git commit -m 'Update API redirect'"
    echo "5. git push"
    echo ""
elif [ "$BACKEND_CODE" = "200" ] && [ "$APIGW_CODE" = "200" ]; then
    echo "✅ Everything appears to be working!"
    echo ""
    echo "If frontend still has issues:"
    echo "- Deploy frontend changes (see above)"
    echo "- Clear browser cache"
    echo "- Check browser console for errors"
    echo ""
else
    echo "⚠️  Multiple issues detected - check each component above"
    echo ""
fi

echo "═══════════════════════════════════════════════════════════"

