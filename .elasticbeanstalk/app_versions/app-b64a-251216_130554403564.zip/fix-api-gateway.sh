#!/bin/bash

# Fix API Gateway 404 - Redeploy and verify configuration

API_ID="p4o6wzh11c"
REGION="us-east-2"

echo "🔧 Fixing API Gateway 404 Error"
echo "API ID: $API_ID"
echo ""

# Get integration details
echo "1️⃣  Getting integration details..."
aws apigatewayv2 get-integrations \
  --api-id "$API_ID" \
  --region "$REGION" \
  --output json > /tmp/integrations.json

if [ $? -eq 0 ]; then
    echo "✅ Retrieved integrations"
    INTEGRATION_ID=$(cat /tmp/integrations.json | grep -o '"IntegrationId": "[^"]*' | head -1 | sed 's/"IntegrationId": "//')
    INTEGRATION_URI=$(cat /tmp/integrations.json | grep -o '"IntegrationUri": "[^"]*' | head -1 | sed 's/"IntegrationUri": "//')
    echo "   Integration ID: $INTEGRATION_ID"
    echo "   Integration URI: $INTEGRATION_URI"
else
    echo "❌ Failed to get integrations"
    exit 1
fi
echo ""

# Get routes
echo "2️⃣  Getting routes..."
aws apigatewayv2 get-routes \
  --api-id "$API_ID" \
  --region "$REGION" \
  --output json > /tmp/routes.json

if [ $? -eq 0 ]; then
    echo "✅ Retrieved routes"
    cat /tmp/routes.json | grep -o '"RouteKey": "[^"]*' | sed 's/"RouteKey": "//' | while read route; do
        echo "   Route: $route"
    done

    # Check if catch-all route exists
    if grep -q '"RouteKey": "ANY /{proxy+}"' /tmp/routes.json; then
        echo "   ✅ Catch-all route exists"
        ROUTE_ID=$(cat /tmp/routes.json | grep -B5 '"RouteKey": "ANY /{proxy+}"' | grep -o '"RouteId": "[^"]*' | sed 's/"RouteId": "//')
        echo "   Route ID: $ROUTE_ID"
    else
        echo "   ⚠️  No catch-all route!"
        echo ""
        echo "   Creating catch-all route..."
        ROUTE_OUTPUT=$(aws apigatewayv2 create-route \
          --api-id "$API_ID" \
          --route-key 'ANY /{proxy+}' \
          --target "integrations/$INTEGRATION_ID" \
          --region "$REGION" \
          --output json)

        if [ $? -eq 0 ]; then
            ROUTE_ID=$(echo "$ROUTE_OUTPUT" | grep -o '"RouteId": "[^"]*' | sed 's/"RouteId": "//')
            echo "   ✅ Created route: $ROUTE_ID"
        else
            echo "   ❌ Failed to create route"
        fi
    fi
else
    echo "❌ Failed to get routes"
fi
echo ""

# Redeploy the stage
echo "3️⃣  Redeploying stage..."
DEPLOY_OUTPUT=$(aws apigatewayv2 create-deployment \
  --api-id "$API_ID" \
  --region "$REGION" \
  --stage-name '$default' \
  --output json 2>&1)

if [ $? -eq 0 ]; then
    echo "✅ Deployed to \$default stage"
else
    # Try prod stage
    DEPLOY_OUTPUT=$(aws apigatewayv2 create-deployment \
      --api-id "$API_ID" \
      --region "$REGION" \
      --stage-name 'prod' \
      --output json 2>&1)

    if [ $? -eq 0 ]; then
        echo "✅ Deployed to prod stage"
    else
        echo "⚠️  Deployment may have failed or auto-deploy is enabled"
        echo "   $DEPLOY_OUTPUT"
    fi
fi
echo ""

# Test the API
echo "4️⃣  Testing API Gateway..."
sleep 2  # Wait for deployment to propagate

RESPONSE=$(curl -s -w "\n%{http_code}" "https://$API_ID.execute-api.$REGION.amazonaws.com/api/events" 2>&1)
HTTP_CODE=$(echo "$RESPONSE" | tail -1)
BODY=$(echo "$RESPONSE" | head -n -1)

if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ SUCCESS! API is responding with HTTP 200"
    echo ""
    echo "Sample response:"
    echo "$BODY" | head -10
elif [ "$HTTP_CODE" = "404" ]; then
    echo "❌ Still getting 404"
    echo "Response: $BODY"
    echo ""
    echo "Possible issues:"
    echo "1. Route not attached to integration - check in AWS Console"
    echo "2. Integration URI format incorrect"
    echo "3. Stage deployment didn't complete"
else
    echo "⚠️  HTTP $HTTP_CODE"
    echo "Response: $BODY"
fi
echo ""

echo "═══════════════════════════════════════════════════════════"
echo "📋 CONFIGURATION SUMMARY"
echo "═══════════════════════════════════════════════════════════"
echo "API Gateway URL: https://$API_ID.execute-api.$REGION.amazonaws.com"
echo "Integration ID: $INTEGRATION_ID"
echo "Integration URI: $INTEGRATION_URI"
echo "Route: ANY /{proxy+}"
echo "Last Test Result: HTTP $HTTP_CODE"
echo ""
echo "Manual test command:"
echo "curl https://$API_ID.execute-api.$REGION.amazonaws.com/api/events"
echo "═══════════════════════════════════════════════════════════"

