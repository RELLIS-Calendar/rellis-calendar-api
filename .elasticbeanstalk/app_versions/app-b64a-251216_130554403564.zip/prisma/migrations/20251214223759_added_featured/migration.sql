-- AlterTable
ALTER TABLE `event` ADD COLUMN `featured` BOOLEAN NOT NULL DEFAULT false;
