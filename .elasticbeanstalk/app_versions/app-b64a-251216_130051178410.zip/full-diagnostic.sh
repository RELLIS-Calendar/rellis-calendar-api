#!/bin/bash

echo "════════════════════════════════════════════════════════════════"
echo "   🔍 DETAILED TROUBLESHOOTING REPORT"
echo "════════════════════════════════════════════════════════════════"
echo ""

cd "/Users/jacksonbailey/Library/CloudStorage/GoogleDrive-jbailey33@leomail.tamuc.edu/My Drive/Web Programming & Interface Design/rellis-calendar-api"

echo "1️⃣  EB ENVIRONMENT STATUS"
echo "────────────────────────────────────────────────────────────────"
eb status
echo ""

echo "2️⃣  EB ENVIRONMENT VARIABLES"
echo "────────────────────────────────────────────────────────────────"
eb printenv
echo ""

echo "3️⃣  TEST BACKEND (HTTP)"
echo "────────────────────────────────────────────────────────────────"
echo "Testing: http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events"
curl -v http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events 2>&1 | head -50
echo ""

echo "4️⃣  RECENT EB LOGS (Last 50 lines)"
echo "────────────────────────────────────────────────────────────────"
eb logs 2>&1 | tail -50
echo ""

echo "5️⃣  CHECK PACKAGE.JSON"
echo "────────────────────────────────────────────────────────────────"
echo "Scripts section:"
cat package.json | grep -A 10 '"scripts"'
echo ""
echo "Dependencies section:"
cat package.json | grep -A 15 '"dependencies"'
echo ""

echo "6️⃣  CHECK LOCAL .ENV"
echo "──────────────────────────────────────��─────────────────────────"
cat .env
echo ""

echo "════════════════════════════════════════════════════════════════"
echo "   📋 PLEASE SHARE THIS OUTPUT"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "Copy the output above and share it so I can diagnose the issue."
echo ""

