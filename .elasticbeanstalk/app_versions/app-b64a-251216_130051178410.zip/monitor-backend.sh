#!/bin/bash

echo "🔄 Monitoring Backend Status..."
echo "This will check every 30 seconds until backend responds with HTTP 200"
echo "Press Ctrl+C to stop"
echo ""
echo "═══════════════════════════════════════════════════════════"

BACKEND_URL="http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events"
COUNT=0
MAX_ATTEMPTS=20  # 10 minutes total

while [ $COUNT -lt $MAX_ATTEMPTS ]; do
    COUNT=$((COUNT + 1))
    TIMESTAMP=$(date '+%H:%M:%S')

    echo ""
    echo "[$COUNT/$MAX_ATTEMPTS] ⏰ $TIMESTAMP - Testing backend..."

    RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" "$BACKEND_URL" 2>&1)
    HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)
    BODY=$(echo "$RESPONSE" | grep -v "HTTP_CODE")

    if [ "$HTTP_CODE" = "200" ]; then
        echo ""
        echo "🎉🎉🎉 SUCCESS! Backend is WORKING! 🎉🎉🎉"
        echo ""
        echo "Backend response:"
        echo "$BODY" | head -20
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "✅ BACKEND IS NOW OPERATIONAL!"
        echo "═══════════════════════════════════════════════════════════"
        echo ""
        echo "📋 NEXT STEPS:"
        echo ""
        echo "1️⃣  Fix API Gateway Routing:"
        echo "   - Go to: https://console.aws.amazon.com/apigateway"
        echo "   - Select API: p4o6wzh11c"
        echo "   - Routes → Click 'ANY /{proxy+}'"
        echo "   - Attach integration if not attached"
        echo "   - Deploy stage"
        echo ""
        echo "2️⃣  Test API Gateway:"
        echo "   curl https://p4o6wzh11c.execute-api.us-east-2.amazonaws.com/api/events"
        echo ""
        echo "3️⃣  Deploy Frontend:"
        echo "   cd rellis-calendar-web"
        echo "   git add public/redirects.json"
        echo "   git commit -m 'Update API endpoint'"
        echo "   git push"
        echo ""
        echo "Or run full diagnostic:"
        echo "   ./complete-diagnostic.sh"
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        break
    elif [ "$HTTP_CODE" = "502" ]; then
        echo "   ⚠️  HTTP 502 - App still starting/crashing"
        echo "   Waiting 30 seconds..."
    elif [ "$HTTP_CODE" = "503" ]; then
        echo "   ⚠️  HTTP 503 - Service temporarily unavailable"
        echo "   Deployment may still be in progress..."
        echo "   Waiting 30 seconds..."
    elif [ -z "$HTTP_CODE" ]; then
        echo "   ❌ No response from backend"
        echo "   Error: $RESPONSE"
        echo "   Waiting 30 seconds..."
    else
        echo "   ⚠️  HTTP $HTTP_CODE"
        echo "   Response: $(echo "$BODY" | head -3)"
        echo "   Waiting 30 seconds..."
    fi

    if [ $COUNT -lt $MAX_ATTEMPTS ]; then
        sleep 30
    fi
done

if [ $COUNT -eq $MAX_ATTEMPTS ] && [ "$HTTP_CODE" != "200" ]; then
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "⚠️  Backend still not responding after $MAX_ATTEMPTS attempts"
    echo "═══════════════════════════════════════════════════════════"
    echo ""
    echo "Troubleshooting steps:"
    echo "1. Check EB status: eb status"
    echo "2. Check EB logs: eb logs"
    echo "3. Check if deployment completed: eb health"
    echo "4. SSH into instance: eb ssh"
    echo "   Then check: ps aux | grep node"
    echo ""
fi

