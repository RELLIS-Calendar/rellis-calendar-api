#!/bin/bash

echo "═══════════════════════════════════════════════════════════"
echo "   🔍 EB INSTANCE DIAGNOSTIC (Run this inside EB SSH)"
echo "═══════════════════════════════════════════════════════════"
echo ""

echo "1️⃣  FILES IN /var/app/current"
echo "────────────────────────────────────────────────────────────────"
ls -la /var/app/current/
echo ""

echo "2️⃣  CHECK PACKAGE FILES"
echo "────────────────────────────────────────────────────────────────"
ls -la /var/app/current/package*.json 2>&1
echo ""

echo "3️⃣  CHECK NODE_MODULES"
echo "────────────────────────────────────────────────────────────────"
if [ -d "/var/app/current/node_modules" ]; then
    echo "✅ node_modules EXISTS"
    ls /var/app/current/node_modules | head -20
else
    echo "❌ node_modules MISSING - This is the problem!"
fi
echo ""

echo "4️⃣  CHECK DIST DIRECTORY"
echo "────────────────────────────────────────────────────────────────"
if [ -d "/var/app/current/dist" ]; then
    echo "✅ dist EXISTS"
    ls -la /var/app/current/dist/
else
    echo "❌ dist MISSING"
fi
echo ""

echo "5️⃣  WEB SERVICE STATUS"
echo "────────────────────────────────────────────────────────────────"
sudo systemctl status web.service --no-pager
echo ""

echo "6️⃣  RECENT WEB SERVICE LOGS"
echo "────────────────────────────────────────────────────────────────"
sudo journalctl -u web.service -n 20 --no-pager
echo ""

echo "7️⃣  CHECK IF NPM INSTALL RAN"
echo "────────────────────────────────────────────────────────────────"
sudo grep -i "npm install\|npm ci" /var/log/eb-engine.log 2>&1 | tail -10
echo ""

echo "8️⃣  MANUAL NPM INSTALL TEST"
echo "────────────────────────────────────────────────────────────────"
echo "Let's manually try npm install:"
cd /var/app/current
npm install 2>&1 | head -30
echo ""

echo "9️⃣  CHECK AFTER MANUAL INSTALL"
echo "────────────────────────────────────────────────────────────────"
if [ -d "/var/app/current/node_modules/@hapi" ]; then
    echo "✅ @hapi/hapi is NOW installed!"
else
    echo "❌ @hapi/hapi still missing"
fi
echo ""

echo "═══════════════════════════════════════════════════════════"
echo "   NEXT STEPS"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "If node_modules was missing and manual npm install worked:"
echo "1. The problem is EB not running npm install during deployment"
echo "2. We need to add a .platform hook or fix the deployment process"
echo ""
echo "Run: sudo systemctl restart web.service"
echo "Then test: curl http://localhost:8080/api/events"
echo ""

