#!/bin/bash
# .platform/hooks/prebuild/01_prisma_generate.sh
# This runs AFTER environment variables are loaded but BEFORE the app starts

set -e

echo "Running Prisma generate with environment variables..."
cd /var/app/staging

# Generate Prisma client
npx prisma generate

echo "Prisma client generated successfully!"

