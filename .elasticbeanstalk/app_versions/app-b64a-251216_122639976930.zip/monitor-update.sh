#!/bin/bash

echo "🔄 Checking Elastic Beanstalk Environment Update Status..."
echo ""
echo "This will monitor the environment until the update completes."
echo "Press Ctrl+C to stop monitoring."
echo ""
echo "═══════════════════════════════════════════════════════════"

cd "/Users/jacksonbailey/Library/CloudStorage/GoogleDrive-jbailey33@leomail.tamuc.edu/My Drive/Web Programming & Interface Design/rellis-calendar-api"

while true; do
    echo ""
    echo "⏰ $(date '+%H:%M:%S') - Checking status..."

    # Get EB status
    STATUS_OUTPUT=$(eb status 2>&1)
    STATUS=$(echo "$STATUS_OUTPUT" | grep "Status:" | awk '{print $2}')
    HEALTH=$(echo "$STATUS_OUTPUT" | grep "Health:" | awk '{print $2}')

    echo "   Status: $STATUS"
    echo "   Health: $HEALTH"

    if [ "$STATUS" = "Ready" ]; then
        echo ""
        echo "✅ Environment is Ready! Testing backend..."
        echo ""

        # Test backend
        RESPONSE=$(curl -s -w "\nHTTP_CODE:%{http_code}" http://rellis-calendar-api-env.eba-b5gm3tfj.us-east-2.elasticbeanstalk.com/api/events 2>&1)
        HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP_CODE" | cut -d: -f2)

        if [ "$HTTP_CODE" = "200" ]; then
            echo "🎉 SUCCESS! Backend is now working!"
            echo ""
            echo "Backend response (first few lines):"
            echo "$RESPONSE" | grep -v "HTTP_CODE" | head -10
            echo ""
            echo "═══════════════════════════════════════════════════════════"
            echo "✅ STEP 1 COMPLETE - Backend is working!"
            echo ""
            echo "📋 NEXT STEPS:"
            echo "1. Fix API Gateway routing (see COMPLETE-FIX-PLAN.txt STEP 3)"
            echo "2. Deploy frontend changes (see STEP 4)"
            echo ""
            echo "Or run the full diagnostic:"
            echo "   ./complete-diagnostic.sh"
            echo "═══════════════════════════════════════════════════════════"
            break
        elif [ "$HTTP_CODE" = "502" ]; then
            echo "⚠️  Still getting 502 error. App may still be starting..."
            echo "   Waiting 30 seconds before next check..."
            sleep 30
        else
            echo "⚠️  HTTP $HTTP_CODE - Unexpected response"
            echo "Response: $RESPONSE"
            sleep 20
        fi
    elif [ "$STATUS" = "Updating" ]; then
        echo "   ⏳ Environment is updating... (this takes 2-3 minutes)"
        sleep 20
    else
        echo "   ⏳ Status: $STATUS - waiting..."
        sleep 15
    fi
done

