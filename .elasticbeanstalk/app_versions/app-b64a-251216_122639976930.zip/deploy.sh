#!/bin/bash

# Build and deploy script for Elastic Beanstalk

set -e

echo "🏗️  Building TypeScript..."
npm run build

echo "📦 Copying files to deploy directory..."
rm -rf deploy/dist
cp -r dist deploy/

echo "📝 Checking deploy directory..."
ls -la deploy/

echo "✅ Build complete! Deploy directory is ready."
echo ""
echo "To deploy to Elastic Beanstalk:"
echo "1. cd deploy"
echo "2. zip -r ../deploy.zip . (exclude node_modules if needed)"
echo "3. Upload deploy.zip to AWS Elastic Beanstalk console"
echo ""
echo "Or if using EB CLI from deploy directory:"
echo "1. cd deploy"
echo "2. eb init (if not already initialized)"
echo "3. eb deploy"

